import React from "react";

const SongCard = () => {
  return <div></div>;
};

export default SongCard;
