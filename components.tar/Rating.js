import React from "react";

const Rating = () => {
  return <div></div>;
};

export default Rating;
